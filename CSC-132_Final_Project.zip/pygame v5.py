#############################################################################################################
# Names: Nicholas Winkelmann, Luke Parks
# Date: May 1, 2021
# Description: Dance Dance Pi-Volution
##############################################################################################################

#importing the necessary libraries: pygame, randint, sys, and GPIO
import pygame as pg
from random import randint
import RPi.GPIO as GPIO
import sys

#-------------------------------------------------------------------------#

# the game class, this is responsible for running the core elements
# of the game and setting them up.
class Game:

    # the constructor
    def __init__(self):
        pass

    # the setupGUI function. This gets various things done for
    # the program so they don't have to be used later. 
    def setupGUI(self):

        # initializing pygame
        pg.init()

        # setting up the screen and naming it. Allowing
        # it to be accessed later.
        global screen
        pg.display.set_caption("Dance Dance Pi-Volution")
        screen = pg.display.set_mode((WIDTH, HEIGHT))

        # setting up the background image. Allowing iot
        # to be used later.
        global background
        background = pg.image.load("ddr background.jpg")

        # setting up the framerate clock and the running variable
        # which allows the main loop to begin.
        global clock
        clock = pg.time.Clock()
        global running
        running = True

    # the setupGPIO function. Sets up the GPIO and creates
    # a list for all the LEDs on the GPIO
    def setupGPIO(self):
        global leds
        GPIO.setmode(GPIO.BCM)
        leds = [22, 23, 24, 25, 26, 27]
        GPIO.setup(leds, GPIO.OUT)


    # a function that creates all of the arrow objects in their
    # respective classes. 
    def setupArrows(self):

        # settiing up the sprites globally and listing them in
        # a group so they can all be acessed at once.
        global all_sprites
        global all_movers
        all_sprites = pg.sprite.Group()

        # the lists of arrows that make generating the sprites at different
        # times easier. Multiple copies are used. These are used for the
        # moving arrows only.
        global ARROWS
        global ARROWS2
        global ARROWS3
        global ARROWS4
        ARROWS = []
        ARROWS2 = []
        ARROWS3 = []
        ARROWS4 = []

        # setting up the gray outlined arrrows in their own class. Each is
        # instantiated with their position on the screen and their image
        # path. They are then added to the all_sprites group
        global DOWN_GRAY
        DOWN_GRAY = stillArrow(WIDTH / 2 + 80, 70, "ddr outline down.png")
        all_sprites.add(DOWN_GRAY)

        global UP_GRAY
        UP_GRAY = stillArrow(WIDTH / 2 - 80, 70, "ddr outline up.png")
        all_sprites.add(UP_GRAY)

        global RIGHT_GRAY
        RIGHT_GRAY = stillArrow(WIDTH / 2 + 230, 70, "ddr outline right.png")
        all_sprites.add(RIGHT_GRAY)
        
        global LEFT_GRAY
        LEFT_GRAY = stillArrow(WIDTH / 2 - 230, 70, "ddr outline left.png")
        all_sprites.add(LEFT_GRAY)
        
        # setting up the first set of moving arrows. Each is instantiated
        # with their position on the screen and their image path. They
        # are then added to all_sprites and then the arrow corresponding
        # arrow lists for use later. 
        global DOWN_MOVER
        DOWN_MOVER = Arrow(WIDTH/2 + 80, 1000, "ddr arrows.png")
        all_sprites.add(DOWN_MOVER)
        ARROWS.append(DOWN_MOVER)

        global UP_MOVER
        UP_MOVER = Arrow(WIDTH/2 - 80, 1000, "ddr arrows up.png")
        all_sprites.add(UP_MOVER)
        ARROWS.append(UP_MOVER)

        global RIGHT_MOVER
        RIGHT_MOVER = Arrow(WIDTH/2 + 230, 1000, "ddr arrows right.png")
        all_sprites.add(RIGHT_MOVER)
        ARROWS.append(RIGHT_MOVER)

        global LEFT_MOVER
        LEFT_MOVER = Arrow(WIDTH/2 - 230, 1000, "ddr arrows left.png")
        all_sprites.add(LEFT_MOVER)
        ARROWS.append(LEFT_MOVER)

        # setting up the second set of moving arrows. Each is instantiated
        # with their position on the screen and their image path. They
        # are then added to all_sprites and then the arrow corresponding
        # arrow lists for use later. 
        global DOWN_MOVER2
        DOWN_MOVER2 = Arrow(WIDTH/2 + 80, 1000, "ddr arrows.png")
        all_sprites.add(DOWN_MOVER2)
        ARROWS2.append(DOWN_MOVER2)

        global UP_MOVER2
        UP_MOVER2 = Arrow(WIDTH/2 - 80, 1000, "ddr arrows up.png")
        all_sprites.add(UP_MOVER2)
        ARROWS2.append(UP_MOVER2)

        global RIGHT_MOVER2
        RIGHT_MOVER2 = Arrow(WIDTH/2 + 230, 1000, "ddr arrows right.png")
        all_sprites.add(RIGHT_MOVER2)
        ARROWS2.append(RIGHT_MOVER2)

        global LEFT_MOVER2
        LEFT_MOVER2 = Arrow(WIDTH/2 - 230, 1000, "ddr arrows left.png")
        all_sprites.add(LEFT_MOVER2)
        ARROWS2.append(LEFT_MOVER2)
        
        # setting up the third set of moving arrows. Each is instantiated
        # with their position on the screen and their image path. They
        # are then added to all_sprites and then the arrow corresponding
        # arrow lists for use later. 
        global DOWN_MOVER3
        DOWN_MOVER3 = Arrow(WIDTH/2 + 80, 1000, "ddr arrows.png")
        all_sprites.add(DOWN_MOVER3)
        ARROWS3.append(DOWN_MOVER3)

        global UP_MOVER3
        UP_MOVER3 = Arrow(WIDTH/2 - 80, 1000, "ddr arrows up.png")
        all_sprites.add(UP_MOVER3)
        ARROWS3.append(UP_MOVER3)

        global RIGHT_MOVER3
        RIGHT_MOVER3 = Arrow(WIDTH/2 + 230, 1000, "ddr arrows right.png")
        all_sprites.add(RIGHT_MOVER3)
        ARROWS3.append(RIGHT_MOVER3)

        global LEFT_MOVER3
        LEFT_MOVER3 = Arrow(WIDTH/2 - 230, 1000, "ddr arrows left.png")
        all_sprites.add(LEFT_MOVER3)
        ARROWS3.append(LEFT_MOVER3)

        # setting up the fourth set of moving arrows. Each is instantiated
        # with their position on the screen and their image path. They
        # are then added to all_sprites and then the arrow corresponding
        # arrow lists for use later. 
        global DOWN_MOVER4
        DOWN_MOVER4 = Arrow(WIDTH/2 + 80, 1000, "ddr arrows.png")
        all_sprites.add(DOWN_MOVER4)
        ARROWS4.append(DOWN_MOVER4)

        global UP_MOVER4
        UP_MOVER4 = Arrow(WIDTH/2 - 80, 1000, "ddr arrows up.png")
        all_sprites.add(UP_MOVER4)
        ARROWS4.append(UP_MOVER4)

        global RIGHT_MOVER4
        RIGHT_MOVER4 = Arrow(WIDTH/2 + 230, 1000, "ddr arrows right.png")
        all_sprites.add(RIGHT_MOVER4)
        ARROWS4.append(RIGHT_MOVER4)

        global LEFT_MOVER4
        LEFT_MOVER4 = Arrow(WIDTH/2 - 230, 1000, "ddr arrows left.png")
        all_sprites.add(LEFT_MOVER4)
        ARROWS4.append(LEFT_MOVER4)

    # a function that initializes the font for pygame and then begins
    # the work for showing the score on screen. Calls the font for
    # the text and then sets the coordinates for the text
    def setupScore(self):
        pg.font.init()

        global font
        font = pg.font.Font('freesansbold.ttf', 30)
        
        global textX
        global textY
        textX = 10
        textY = 10
        
    # a function that displays the text for the beginning of the game.
    # Tells the player to press the enter button to begin.
    def enter_to_start(self):
        global start
        start = font.render("Press Enter to Begin!", True, (0, 0, 0,))
        

# ---------------------------------------------------------------------------------------------------------------#

# the stillArrow class which encompasses the gray outline arrows.
# These do not move and are separate from the moving arrows.
# Inherits from pygame's sprite class
class stillArrow(pg.sprite.Sprite):

    # the constructor
    def __init__(self, x, y, img_path):
        super().__init__()

        # creating the image for each object in the class
        # uses the img path passed through at instantiation.
        # Also shrinks the original image to a size that better
        # fits
        self.image = pg.image.load(img_path).convert_alpha()
        self.size = self.image.get_size()
        self.image = pg.transform.scale(self.image, (int(self.size[0] *(0.22)), int(self.size[1] * (0.22))))

        # gets a rectangle of the sprite for easier work and positioning.
        # positions the arrow
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

#------------------------------------------------------------------------------------------------------------------#

# the Arrow class. This encompasses all the moving arrows.
# Inherits from the pygame sprite class
class Arrow(pg.sprite.Sprite):

    # the constructor
    def __init__(self, x, y, img_path):
        super().__init__()

        # creating the image for each object in the class
        # uses the img path passed through at instantiation.
        # Also shrinks the original image to a size that better
        # fits
        self.image = pg.image.load(img_path).convert_alpha()
        self.size = self.image.get_size()
        self.image = pg.transform.scale(self.image, (int(self.size[0] *(1/5)), int(self.size[1] * (1/5))))

        # gets a rectangle of the sprite for easier work and positioning.
        # positions the arrow
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

        # setting their repsective x and y values to what
        # passed into the class as parameters
        self.x = x
        self.y = y

        # establishing the velocities of the arrows as 0
        # These will be manipulated later
        self.dx = 0
        self.dy = 0

        # establishing the position variable, used to
        # track where it is on the screen for scoring and
        # respawning. Also the moving variable which tells
        # if the arrow is moving at the current time
        self.position = y
        self.moving = False

    # the arrowMove function. When called, it changes
    # the specific arrow's velocity and moving variable.
    # changes based on difficulty.
    def arrowMove(self):
        if difficulty == "Easy":
            self.dy = -5
        elif difficulty == "Medium":
            self.dy = -7
        else:
            self.dy = -10
        self.moving = True

    # the update function which is used in the main program
    # all the time. Actually moves the arrows according to
    # their velocities. Also resets their positions back to
    # the bottom after the screen goes up off the screen.
    # resets their movement back to zero when they go off
    # the screen. Changes based on difficulty selected.
    def update(self):
        global music
        self.rect.x = self.rect.x + self.dx
        self.rect.y = self.rect.y + self.dy
        if self.moving == True:
            if difficulty == "Easy":
                self.position -= 5
            if difficulty == "Medium":
                self.position -= 7
            if difficulty == "Hard":
                self.position -= 10
        if self.position < -50 :
            self.rect.center = (self.x, self.y)
            self.position = self.y
            self.dy = 0
            self.moving = False
        if not music:
            self.dy = 0
            self.rect.y = 1200

# -------------------------------------------------------------------------------------------------------------------- #

# the arrow spawn function. This is an algorithm
# devoted to choosing which arrows to "spawn" by
# moving them upwards onto the screen and assigning
# them movement. Operates by multiple counters.
def arrow_spawn():
    global arrow_counter
    if (update_counter % 30) == 0:
        arrow_counter += 1
        not_4 = True
        #print(arrow_counter)
        
        if arrow_counter % 4 == 0:
            #print("arrow 2")
            current_arrow2 = ARROWS2[randint(0,3)]
            not_4 = False

            #ARROWS2[randint(0,3)].arrowMove()

            current_arrow2.arrowMove()

        elif arrow_counter % 3 == 0:
            #print("arrow 3")
            current_arrow3 = ARROWS3[randint(0,3)]

            #ARROWS3[randint(0,3)].arrowMove()

            current_arrow3.arrowMove()

        elif arrow_counter % 2 == 0 and not_4 :
            #print("arrow 4")
            current_arrow4 = ARROWS4[randint(0,3)]

            #ARROWS3[randint(0,3)].arrowMove()

            current_arrow4.arrowMove()
            
        else:
            #print("arrow 1")
            current_arrow = ARROWS[randint(0,3)]

            #ARROWS[randint(0,3)].arrowMove()

            current_arrow.arrowMove()

# the ShowScore function. This simply renders the
# score text into a global variable for use in the
# main loop.
def ShowScore(score_value):
    global score
    score = font.render("Score : {}".format(str(score_value)), True, (0, 0, 0,))

# the ShowFinal function. This simply renders
# the final score and instructions to close
# the game.
def ShowFinal(score_value):
    global final_text
    final_text = font.render("Final Score : {} Press Escape to Quit.".format(str(score_value)), True,  (0, 0, 0))

# sets the difficulty text and resets it per change in difficulty
def ShowDifficulty(difficulty):
    global diff_script
    global change_script
    diff_script = font.render("Difficulty level : {}".format(difficulty), True, (0,0,0))
    change_script = font.render("Press 1, 2, or 3 for difficulty settings", True, (0,0,0))
    
######################################################################################################################################
#
#  Main Program
#
######################################################################################################################################

# constants
WIDTH = 800
HEIGHT = 500
STARTED = False

# calling the game class g
g = Game()

# initializes pygame's music. Loads the default song
# and sets the volume. 
pg.mixer.init()
pg.mixer.music.load("overjohn.mp3")
pg.mixer.music.set_volume(1)

# calls the setupGUI function
g.setupGUI()

# calls the setupGPIO function
g.setupGPIO()

# calls the setupArrows function
g.setupArrows()

# makes the counter variables. update_counter
# is used for timing when new arrows are to be
# randomly chosen. arrow_counter is used to tell
# which list of arrows the new arrow is chosen from.
# the led_counter times how long the LEDs are lit up
# without using time.sleep() which stops the whole
# program
update_counter = 0
arrow_counter = 0
led_counter = 0

# used to speak the final message only once
final_message = True
final = False

# the default difficulty setting
difficulty = "Easy"

# the score and setting it up by calling the
# function
score_value = 0
g.setupScore()

# calls the function to set up the beginning text
g.enter_to_start()

# the main loop for the program. Runs by checking to see
# if running is true. contains a nested loop which is
# activated if the beginning text's condition is met:
# pressing the enter key
while running:

    # the second, nested loop. Becomes true after
    # the enter key is pressed at the beginning
    while STARTED:

        # manages the framerate
        clock.tick(60)

        # checks the events happening in the game
        for event in pg.event.get():          

            # checks if a key is being pressed down
            # and then manages which one was pressed.
            # There is an if statement for each possible
            # arrow and their respective positions needed
            # to gain a point and light up the GPIO LEDS
            if event.type == pg.KEYDOWN :

                # the checking algorithm for scoring. This is for all the
                # down arrows. If you time the arrow key press right, the green light
                # will light up, if not, the red one will light up. The corresponding
                # arrow light will light up regardless.
                if event.key == pg.K_DOWN:
                    GPIO.output(27, True)
                    if (DOWN_MOVER.position > (DOWN_GRAY.rect.y + 56) - 40) and (DOWN_MOVER.position < (DOWN_GRAY.rect.y + 56) + 40):
                        score_value += 1
                        GPIO.output(23, True)
                    elif (DOWN_MOVER2.position > (DOWN_GRAY.rect.y + 56) - 40) and (DOWN_MOVER2.position < (DOWN_GRAY.rect.y + 56) + 40):
                        score_value += 1
                        GPIO.output(23, True)
                    elif (DOWN_MOVER3.position > (DOWN_GRAY.rect.y + 56) - 40) and (DOWN_MOVER3.position < (DOWN_GRAY.rect.y + 56) + 40):
                        score_value += 1
                        GPIO.output(23, True)
                    elif (DOWN_MOVER4.position > (DOWN_GRAY.rect.y + 56) - 40) and (DOWN_MOVER4.position < (DOWN_GRAY.rect.y + 56) + 40):
                        score_value += 1
                        GPIO.output(23, True)
                    else:
                        GPIO.output(22, True)
                        
                # the checking algorithm for scoring. This is for all the
                # up arrows. If you time the arrow key press right, the green light
                # will light up, if not, the red one will light up. The corresponding
                # arrow light will light up regardless.    
                if event.key == pg.K_UP:
                    GPIO.output(24, True)
                    if (UP_MOVER.position > (UP_GRAY.rect.y + 56) - 40) and (UP_MOVER.position < (UP_GRAY.rect.y + 56) + 40):
                        GPIO.output(23, True)
                        score_value += 1
                    elif (UP_MOVER2.position > (UP_GRAY.rect.y + 56) - 40) and (UP_MOVER2.position < (UP_GRAY.rect.y + 56) + 40):
                        score_value += 1
                        GPIO.output(23, True)
                    elif (UP_MOVER3.position > (UP_GRAY.rect.y + 56) - 40) and (UP_MOVER3.position < (UP_GRAY.rect.y + 56) + 40):
                        score_value += 1
                        GPIO.output(23, True)
                    elif (UP_MOVER4.position > (UP_GRAY.rect.y + 56) - 40) and (UP_MOVER4.position < (UP_GRAY.rect.y + 56) + 40):
                        score_value += 1
                        GPIO.output(23, True)
                    else:
                        GPIO.output(22, True)
                               
                # the checking algorithm for scoring. This is for all the
                # right arrows. If you time the arrow key press right, the green light
                # will light up, if not, the red one will light up. The corresponding
                # arrow light will light up regardless.
                if event.key == pg.K_RIGHT:
                    GPIO.output(25, True)
                    if (RIGHT_MOVER.position > (RIGHT_GRAY.rect.y + 56) - 40) and (RIGHT_MOVER.position < (RIGHT_GRAY.rect.y + 56) + 40):
                        score_value += 1
                        GPIO.output(23, True)
                    elif (RIGHT_MOVER2.position > (RIGHT_GRAY.rect.y + 56) - 40) and (RIGHT_MOVER2.position < (RIGHT_GRAY.rect.y + 56) + 40):
                        score_value += 1
                        GPIO.output(23, True)
                    elif (RIGHT_MOVER3.position > (RIGHT_GRAY.rect.y + 56) - 40) and (RIGHT_MOVER3.position < (RIGHT_GRAY.rect.y + 56) + 40):
                        score_value += 1
                        GPIO.output(23, True)
                    elif (RIGHT_MOVER4.position > (RIGHT_GRAY.rect.y + 56) - 40) and (RIGHT_MOVER4.position < (RIGHT_GRAY.rect.y + 56) + 40):
                        score_value += 1
                        GPIO.output(23, True)
                    else:
                        GPIO.output(22, True)
                        
                # the checking algorithm for scoring. This is for all the
                # left arrows. If you time the arrow key press right, the green light
                # will light up, if not, the red one will light up. The corresponding
                # arrow light will light up regardless.
                if event.key == pg.K_LEFT:
                    GPIO.output(26, True)
                    if (LEFT_MOVER.position > (LEFT_GRAY.rect.y + 56) - 40) and (LEFT_MOVER.position < (LEFT_GRAY.rect.y + 56) + 40):
                        score_value += 1
                        GPIO.output(23, True)
                    elif (LEFT_MOVER2.position > (LEFT_GRAY.rect.y + 56) - 40) and (LEFT_MOVER2.position < (LEFT_GRAY.rect.y + 56) + 40):
                        score_value += 1
                        GPIO.output(23, True)
                    elif (LEFT_MOVER3.position > (LEFT_GRAY.rect.y + 56) - 40) and (LEFT_MOVER3.position < (LEFT_GRAY.rect.y + 56) + 40):
                        score_value += 1
                        GPIO.output(23, True)
                    elif (LEFT_MOVER4.position > (LEFT_GRAY.rect.y + 56) - 40) and (LEFT_MOVER4.position < (LEFT_GRAY.rect.y + 56) + 40):
                        score_value += 1
                        GPIO.output(23, True)
                    else:
                        GPIO.output(22, True)
                        
                # used to check if the escape key is pressed.
                # this quits the game at any moment the key is
                # pressed.
                if event.key == pg.K_ESCAPE:
                    GPIO.cleanup()
                    pg.quit()
                    sys.exit()

        # incrementing the update_counter variable
        # this isincrementing by 0.5 each time
        update_counter += 0.5
        led_counter += 1

        # this checks to see if the music is still
        # playing. Returns false if the music is still
        # playing
        music = pg.mixer.music.get_busy()

        # updating all the sprites at the same time
        # with their respective values.
        all_sprites.update()

        # calls the arrow_spawn function to spawn arrows
        if final_message:
            arrow_spawn()

        # drawing the sprites on the screen
        all_sprites.draw(screen)
        pg.display.flip()

        # rendering the score text and the final score
        # texts based on the current score values
        ShowScore(score_value)
        ShowFinal(score_value)

        # updating the background
        screen.blit(background, (0,0))

        # two if statements to see if the music is still playing.
        # keeps the regular score text on the screen while the music
        # is playing, changes to the final message otherwise. 
        if music and not final: 
            screen.blit(score, (textX, textY))
        if not music:
            
            final = True
            
        if final:
        
            # an if statement that checks to see if the final verbal
            # message describing how well you did was played. If it
            # hasn't been played, it will play the one correpsonding
            # to your score. If it has been played, this is not
            # executed.
            if final_message:
                if score_value < 10:
                    pg.mixer.music.load("bad john.mp3")
                    pg.mixer.music.set_volume(1)
                    pg.mixer.music.play()
                elif score_value > 10 and score_value < 25:
                    pg.mixer.music.load("meh john.mp3")
                    pg.mixer.music.set_volume(1)
                    pg.mixer.music.play()
                elif score_value > 25 and score_value < 40:
                    pg.mixer.music.load("good john.mp3")
                    pg.mixer.music.set_volume(1)
                    pg.mixer.music.play()
                elif score_value > 40 and score_value < 50 :
                    pg.mixer.music.load("great john.mp3")
                    pg.mixer.music.set_volume(1)
                    pg.mixer.music.play()
                else:
                    pg.mixer.music.load("perfect john.mp3")
                    pg.mixer.music.set_volume(1)
                    pg.mixer.music.play()
                final_message = False
            #final = False
            
            screen.blit(final_text, (WIDTH/2 - 260, HEIGHT/2 - 40))
            all_sprites.clear(screen, background)
        
        if led_counter % 30 == 0:
            GPIO.output(leds, False)

    # checks events that are happening in the program.
    # checks for the enter key being pressed. Once that
    # condition is met, the STARTED variable becomes True
    # activating the nested while loop. Also spawns
    # the first arrow and begins the music. Also checks
    # to see if the player wants to quit.
    for event in pg.event.get():
        if event.type == pg.KEYDOWN :
            if event.key == pg.K_RETURN :
                STARTED = True
                ARROWS[randint(0,3)].arrowMove()
                pg.mixer.music.play()
            if event.key == pg.K_ESCAPE:
                GPIO.cleanup()
                pg.quit()
                sys.exit()
            if event.key == pg.K_1:
                difficulty = "Easy"
                pg.mixer.music.load("overjohn.mp3")
            if event.key == pg.K_2:
                difficulty = "Medium"
                pg.mixer.music.load("Pygame.mp3")
            if event.key == pg.K_3:
                difficulty = "Hard"
                pg.mixer.music.load("gourmet john.mp3")

    # updating the GUI
    ShowDifficulty(difficulty)
    pg.display.flip()
    screen.blit(background, (0,0))
    screen.blit(start, (WIDTH/2 - 160, HEIGHT/2 - 40))
    screen.blit(diff_script, (WIDTH/2 - 160, HEIGHT/2))
    screen.blit(change_script, (WIDTH/2 - 260, HEIGHT/2 + 40))
